#include <Rcpp.h>
using namespace Rcpp;

//' Compute the adjusted weights
//'
//' @param matrix of the predicted  values
//'
//' @export
// [[Rcpp::export]]
NumericVector w(NumericMatrix zs) {
  
  // Initialize variables
  int rows = zs.nrow();
  int cols = zs.ncol();
  NumericVector wresults(cols);
  
  // New weights are calculated by summing the zHats by column and then dividing
  // by the number of rows in the matrix
  for (int k = 0; k < cols; ++k) {
    
    double neweights = 0;
    for (int i = 0; i < rows; ++i) {
      neweights +=  zs(i,k);
    }
    wresults[k] = neweights / rows;
  }
  return wresults;
}
